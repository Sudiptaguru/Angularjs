var app = angular.module('myApp', ['reviewApp']);
// var app = angular.module('myApp', []);
// app.controller('MyController', ['$scope',function($scope){
	// $scope.name = 'Sudipta Guru';
	// $scope.age = 28;
	// $scope.firstname = 'Sudipta';
	// $scope.lastname = 'Guru';
	// $scope.fullname = function(){
	// 	return $scope.firstname + " " + $scope.lastname;
	// };
	// $scope.isSpy = true;
	// $scope.codename = 'Sudipta';
	// $scope.employees = [
	// {
	// 	fname: 'Sudipta',
	// 	lname: 'Guru',
	// 	salary: 50000
	// },
	// {
	// 	fname: 'Ram',
	// 	lname: 'Das',
	// 	salary: 40000
	// },
	// {
	// 	fname: 'Shyam',
	// 	lname: 'Das',
	// 	salary: 30000
	// }
	// ]
	// $scope.count = 0;
	// $scope.show = true;
	// $scope.toggleshow = function(){
	// 	$scope.show = !$scope.show;
	// }
// 	$scope.form = {};

// 	$scope.addReview = function(){
// 		$scope.reviews.push($scope.form);
// 		$scope.form = {};
// 	}
// 	$scope.reviews = [
// 	{
// 		comment: 'Could this be more awesome?',
// 		// by: 'Sudipta Guru'
// 		by: 'sudipta@gmail.com'
// 	},
// 	{
// 		comment: 'How do you do?',
// 		// by: 'Ram Das'
// 		by: 'ram@gmail.com'
// 	}
// 	];
// }]);

// app.directive('userinformation',function(){
// 	return{
// 		// restrict: 'E',
// 		restrict: 'A',
// 		templateUrl: 'userinfo.html'
// 	};
// });