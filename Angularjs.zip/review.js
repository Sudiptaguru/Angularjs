var app = angular.module('reviewApp', []);
app.controller('MyController', ['$scope',function($scope){
	$scope.form = {};

	$scope.addReview = function(){
		$scope.reviews.push($scope.form);
		$scope.form = {};
	}
	$scope.reviews = [
	{
		comment: 'Could this be more awesome?',
		// by: 'Sudipta Guru'
		by: 'sudipta@gmail.com'
	},
	{
		comment: 'How do you do?',
		// by: 'Ram Das'
		by: 'ram@gmail.com'
	}
	];
}]);

app.directive('userinformation',function(){
	return{
		// restrict: 'E',
		restrict: 'A',
		templateUrl: 'userinfo.html'
	};
});